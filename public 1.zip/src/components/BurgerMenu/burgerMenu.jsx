import { stack as Menu } from 'react-burger-menu';
import { NavLink } from 'react-router-dom';
import { useState } from 'react';
import './burgerMenu.scss';

const BurgerMenu = () => {
    const [isOpen, setIsOpen] = useState(false); // добавили состояние
    const handleStateChange = (state) => setIsOpen(state.isOpen);
    const closeMenu = () => setIsOpen(false);

    return (
        <Menu 
            right 
            width={280}
            isOpen={isOpen}
            onStateChange={handleStateChange}  
        >
            <NavLink className="menu-item" to="/" onClick={closeMenu}>Главная</NavLink>
            <NavLink className="menu-item" to="/aboutme" onClick={closeMenu}>Обо мне</NavLink>
            <NavLink className="menu-item" to="/project" onClick={closeMenu}>Проекты</NavLink>
            <NavLink className="menu-item" to="/contacts" onClick={closeMenu}>Контакты</NavLink>
        </Menu>
    )
}

export default BurgerMenu;

